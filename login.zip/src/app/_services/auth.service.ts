import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


const AUTH_API = 'https://salixv3dev.radiusdirect.net/coreapi/clientAdminLogin';
const YOUTH_API = 'https://salixv3dev.radiusdirect.net/coreapi/v2/noteslist?meeting=1258&category_id=16&page=1&limit=10';

// const httpOptions = {
//   headers: new HttpHeaders({ 'Content-Type': 'application/json' })
// };

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }








   login(credentials): Observable<any> {
    return this.http.post(AUTH_API, {
      email: credentials.email,
      password: credentials.password
    });
  }

  list(): Observable<any> {
    return this.http.get(YOUTH_API, {
      
    });
  }

  
}