import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  userList: any=[];
  userDrop: any=[];

  constructor(private authService: AuthService,
    private router: Router) { }

  ngOnInit(): void {
    this.getUserList();
    this.getUserDrop();
  }

  logout() {
    localStorage.removeItem("currentUser");
    this.router.navigate(['/']);
  }

  getUserList():void{
    this.authService.list().subscribe(resp => {
      console.log(resp.result);
      this.userList = resp.result
    },err => {
      console.log(err);
    });
  }

getUserDrop():void{
  this.authService.drop().subscribe(res => {
    console.log(res.result);
    this.userDrop = res.result
  },err => {
    console.log(err);
  });
}

}


