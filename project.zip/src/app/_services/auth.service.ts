import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TokenStorageService } from '../_services/token-storage.service';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

const AUTH_API = 'https://salixv3dev.radiusdirect.net/coreapi/clientAdminLogin';
const YOUTH_API = 'https://salixv3dev.radiusdirect.net/coreapi/v2/noteslist?meeting=1258&category_id=16&page=1&limit=10';
const DROPDOWN_API ='https://salixv3dev.radiusdirect.net/coreapi/v2/notesTasksCatList?category_type=notes';


// var bearerToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTEwOTQsInVzZXJUeXBlIjoiMCIsImNvbXBhbnkiOjEsImVtYWlsIjoiYWRtaW5AdjNkZXZyZC5jb20iLCJyb2xlIjowLCJpYXQiOjE2MDc0NDQwNzN9.WVPPTcG0KLXX38AVLWuCOgAiwaWhtEfwzzYXQAPbOw8';
// var headers = new HttpHeaders({
//   'Content-Type': 'application/json',
//   'Authorization': 'Bearer ' + bearerToken
// });

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // isLoggedIn: any;
 // jwtToken = localStorage.getItem('currentUser');
  constructor(private http: HttpClient,private router: Router,
    private tokenStorage: TokenStorageService,) { }




    sendToken(token: string) {
      localStorage.setItem("currentUser", token)
    }
    getToken() {
      return localStorage.getItem("currentUser")
    }
    isLoggedIn() {
      return this.getToken() !== null;
    }
    logout() {
      localStorage.removeItem("currentUser");
      this.router.navigate(['/']);
    }





  login(credentials): Observable<any> {
    return this.http.post(AUTH_API, {
      email: credentials.email,
      password: credentials.password
    }).pipe(map(user => {
      // store user details and jwt token in local storage to keep user logged in between page refreshes
      localStorage.setItem('currentUser', JSON.stringify(user));
     // this.currentUserSubject.next(user);
    // console.log(currentUser);
     
      return user;
  }));
  }

 
  list(): Observable<any> {
    return this.http.get(YOUTH_API);
  }


  drop(): Observable<any> {
    return this.http.get(DROPDOWN_API);
  }

 
}
